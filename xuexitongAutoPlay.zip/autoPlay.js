/*
 *  打开浏览器控制台，鼠标右键点击检查（谷歌、QQ浏览器是这样）
 *  复制下面代码，粘贴到控制台上，回车。
 */



let title = document.querySelector('#mainid>h1')

function alert(text,timeout = 10000){
    let div =  document.createElement('div')
    div.innerHTML = text
    div.setAttribute('style','position:fixed; left:0vw; top:0vh; ;height: 20vh; width:30vw;text-align:center; background:#0006;color:#fff;font-size:20px')
    document.body.appendChild(div)
    setTimeout(()=>{
        div.style.display = 'none'
    },timeout)
}

async function autoPlay() {

    let videoBox = []

    let iframe = document.querySelector('iframe').contentWindow.document.querySelectorAll('iframe')
    alert(`正在自动播放>>>`,2000)
    await new Promise(resolve => {

        setTimeout(() => {
            for (let i of iframe) {
                videoBox.push(i.contentWindow)
            }
            resolve()
        }, 2000)
    })


    function nextPage() {
        document.querySelector('.orientationright').click()
        let tryTimes = 0
        window.interval = setInterval(() => {
            let newTitle = document.querySelector('#mainid>h1')
            if (newTitle && newTitle !== title) {
                let iframeReady = document.querySelector('iframe').contentWindow.document.querySelectorAll('iframe').length
                if (iframeReady || tryTimes > 5) {
                    title = newTitle
                    window.clearInterval(window.interval)
                    window.interval = null
                    autoPlay()
                }

            }
            tryTimes++
        }, 100)
    }




    function playVideo(video, rate) {
        rate.click()
        video.play()
        return new Promise(resolve => {
            video.addEventListener('ended', () => {
                resolve()
            })
        })
    }
    async function playVideos() {
        for (let i = 0; i < videoBox.length; i++) {
            let video = videoBox[i].document.querySelector('video')
            let rate = videoBox[i].document.querySelector('.vjs-playback-rate').firstElementChild
            await playVideo(video, rate)
        }
        nextPage()
    }


    if (videoBox.length > 0) {
        playVideos()
    } else {
        nextPage()
    }
}






function init(){
    alert(`正在自动播放，请在网络质量好的环境使用，默认播放速度1.25倍。</br>自动播放过程中，如跳转到其他视频后请点击按钮手动开始。`)

    let appConsole = document.createElement('div')
    appConsole.setAttribute('style',
        'position:fixed;z-index:1000;left:30vw; top:0vh;height: 15vh; width:20vw;text-align:center; background:#fff;border:1px solid #000;')
    let p = document.createElement('p')
    p.append('学习通自动播放中')

    let button1 = document.createElement('button')
    button1.append('手动开始')
    button1.setAttribute('style','font-size:17px;margin-top: 3vh;')
    button1.addEventListener('click',autoPlay)

    appConsole.appendChild(p)
    appConsole.appendChild(button1)

    document.body.appendChild(appConsole)
    autoPlay()

}
init()
